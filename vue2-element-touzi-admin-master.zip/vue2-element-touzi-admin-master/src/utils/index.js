import axios from './axios'

export {
	axios,
}