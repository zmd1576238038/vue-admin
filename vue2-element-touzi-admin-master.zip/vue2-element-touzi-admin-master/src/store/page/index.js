import page from './page.js'


export default page;