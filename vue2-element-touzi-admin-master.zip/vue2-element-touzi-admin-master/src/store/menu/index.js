import menu from './menu.js'
export default menu