<template>
    <div class="nofundcontain">
        <div class="nofund_container">
            <h1>对不起，您访问的页面不存在！</h1>
        </div>
    </div>
</template>

<script>

    export default {
        data(){
            return {
            
            }
        }
              
    }
</script>

<style lang="less">
	
   
</style>


