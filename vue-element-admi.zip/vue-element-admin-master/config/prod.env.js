'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"https://easy-mock.com/mock/5aa5f401a99e172c9fe77f05/vue-element-admin"',
}
